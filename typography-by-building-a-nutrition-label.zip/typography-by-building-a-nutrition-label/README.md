# Typography by Building a Nutrition Label

A Pen created on CodePen.io. Original URL: [https://codepen.io/marjandeveloper/pen/OJoBdvq](https://codepen.io/marjandeveloper/pen/OJoBdvq).

